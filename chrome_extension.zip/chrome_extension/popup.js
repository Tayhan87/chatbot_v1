// --- UI Elements ---
const signInBtn = document.getElementById('sign-in-btn');
const mainUI = document.getElementById('main-ui');
const meetingSelect = document.getElementById('meeting-select');
const chatArea = document.getElementById('chat-area');
const userInput = document.getElementById('user-input');
const sendBtn = document.getElementById('send-btn');
const micBtn = document.getElementById('mic-btn');
const speechToggle = document.getElementById('speech-toggle');

// --- State ---
let signedIn = false;
let meetings = [];
let selectedMeeting = null;
let speechReplies = false;

// --- Mock Data/Functions (replace with backend integration) ---
function mockSignIn() {
  // Simulate sign-in and store state
  signedIn = true;
  chrome.storage.local.set({ signedIn: true });
  showMainUI();
}

function mockFetchMeetings() {
  // Simulate fetching meetings from backend
  meetings = [
    { id: '1', title: 'Team Sync - Monday' },
    { id: '2', title: 'Project Kickoff' },
    { id: '3', title: '1:1 with Manager' }
  ];
  populateMeetings();
}

function mockAssistantReply(message) {
  // Simulate assistant reply
  return `You asked about '${message}' for meeting '${selectedMeeting ? selectedMeeting.title : ''}'.`;
}

// --- UI Logic ---
function showMainUI() {
  signInBtn.classList.add('hidden');
  mainUI.classList.remove('hidden');
  mockFetchMeetings();
}

function showSignIn() {
  signInBtn.classList.remove('hidden');
  mainUI.classList.add('hidden');
}

function populateMeetings() {
  meetingSelect.innerHTML = '';
  meetings.forEach(meeting => {
    const option = document.createElement('option');
    option.value = meeting.id;
    option.textContent = meeting.title;
    meetingSelect.appendChild(option);
  });
  if (meetings.length > 0) {
    selectedMeeting = meetings[0];
  }
}

meetingSelect.addEventListener('change', () => {
  selectedMeeting = meetings.find(m => m.id === meetingSelect.value);
});

// --- Chat Logic ---
function appendMessage(sender, text) {
  const div = document.createElement('div');
  div.textContent = `${sender}: ${text}`;
  chatArea.appendChild(div);
  chatArea.scrollTop = chatArea.scrollHeight;
}

function handleSend() {
  const message = userInput.value.trim();
  if (!message) return;
  appendMessage('You', message);
  userInput.value = '';
  // Simulate assistant reply
  const reply = mockAssistantReply(message);
  appendMessage('Assistant', reply);
  if (speechReplies) speak(reply);
}

sendBtn.addEventListener('click', handleSend);
userInput.addEventListener('keydown', e => {
  if (e.key === 'Enter') handleSend();
});

// --- Speech Recognition (Web Speech API) ---
let recognition;
if ('webkitSpeechRecognition' in window) {
  recognition = new webkitSpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = 'en-US';

  recognition.onresult = function(event) {
    const transcript = event.results[0][0].transcript;
    userInput.value = transcript;
    handleSend();
  };
  recognition.onerror = function(event) {
    alert('Speech recognition error: ' + event.error);
  };
}

micBtn.addEventListener('click', () => {
  if (recognition) {
    recognition.start();
  } else {
    alert('Speech recognition not supported in this browser.');
  }
});

// --- Speech Synthesis (Replies) ---
function speak(text) {
  if (!('speechSynthesis' in window)) return;
  const utter = new SpeechSynthesisUtterance(text);
  utter.lang = 'en-US';
  window.speechSynthesis.speak(utter);
}

speechToggle.addEventListener('change', () => {
  speechReplies = speechToggle.checked;
  chrome.storage.local.set({ speechReplies });
});

// --- Sign In Button ---
signInBtn.addEventListener('click', mockSignIn);

// --- Initialization ---
function init() {
  chrome.storage.local.get(['signedIn', 'speechReplies'], (result) => {
    signedIn = !!result.signedIn;
    speechReplies = !!result.speechReplies;
    speechToggle.checked = speechReplies;
    if (signedIn) {
      showMainUI();
    } else {
      showSignIn();
    }
  });
}

document.addEventListener('DOMContentLoaded', init);
